using { sap.capire.products as database } from '../db/schema';

service AdminService {

    entity ProductsSrv as projection on database.Products;
    entity CategoriesSrv as projection on database.Categories;

}